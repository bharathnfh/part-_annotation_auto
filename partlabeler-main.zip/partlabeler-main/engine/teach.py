"""Teach & Transfer, part one: learn a labeled source dataset and prove the model reproduces it.

    analyse -> prepare (optional parent-object crop, time-block split) -> train (RF-DETR)
            -> prove on held-out frames -> run folder: settings.json, report.json, report.md, model/

The source is a YOLO folder (images/, labels/, classes.txt or data.yaml), usually frames of one video.
"Annotate as per source": settings.json records the source's classes, sampling step and file naming,
which `transfer` copies. Prepare and train are skipped on a rerun when their outputs are complete, and
an interrupted training run resumes from its last epoch.
"""
import hashlib
import json
import shutil
import time
from collections import Counter, defaultdict
from itertools import groupby
from pathlib import Path

import numpy as np
import supervision as sv
from PIL import Image, ImageOps

from engine.project import FRAME_RE, IMAGE_EXTS, mirrored_pairs, read_classes

TARGETS = {"mAP50": 0.90, "recall": 0.90, "stress_drop": 10.0}   # stress drop in mAP50 points
THRESHOLDS = [round(float(t), 2) for t in np.arange(0.1, 0.9, 0.05)]
TINY_PX = 8            # shorter box side, in pixels at the training resolution
FEW_BOXES = 10
FEW_FRAMES = 0.10      # a class present in under 10% of labeled frames
PARENT_MARGIN = 0.12
PARENT_EVERY = 4     # video frames: the parent is searched on every 4th frame, its crop reused in between


# ---- reading the source -------------------------------------------------------------------
def classes_of(dataset_dir) -> list[str]:
    for name in ("classes.txt", "data.yaml", "data.yml"):
        if (Path(dataset_dir) / name).exists():
            return read_classes(Path(dataset_dir) / name)
    raise FileNotFoundError(f"{dataset_dir} has no classes.txt or data.yaml")


def source_items(dataset_dir) -> list[dict]:
    """Every image under images/ with its label file (labels/<same path>.txt, None when missing), in time
    order: by video prefix and frame number when names end in _fNNNNNN, else by name."""
    images, labels = Path(dataset_dir) / "images", Path(dataset_dir) / "labels"
    if not images.is_dir():
        raise FileNotFoundError(f"{dataset_dir} has no images/ folder")
    items = []
    for p in images.rglob("*"):
        if p.suffix.lower() not in IMAGE_EXTS:
            continue
        rel = p.relative_to(images).parent / p.stem
        label = labels / rel.parent / (p.stem + ".txt")
        name = rel.as_posix()
        m = FRAME_RE.search(name)
        items.append({"name": name.replace("/", "__"), "image": p, "label": label if label.exists() else None,
                      "key": (name[:m.start()], int(m.group(1))) if m else (name, -1)})
    return sorted(items, key=lambda it: it["key"])


def task_dataset(project, task_id: int, out, progress=None, should_stop=None) -> dict | None:
    """A project task's confirmed frames as a YOLO box dataset for teach(): images/, labels/ (one box per part;
    outlines give their boxes; a confirmed frame without parts is an empty file, a frame the model must leave
    empty), classes.txt. Names are <task>_f<frame> so the frame step and the time order are known. Projects with
    outlines also get masks/<name>.png, the parts' pixels (recoloured copies keep exactly those), and
    polygons/<name>.txt, each part's outline as a YOLO segmentation row in the order of the box rows (for models
    that outline parts). Returns {"frames", "boxes", "empty"}, or None when stopped."""
    out = Path(out)
    (out / "images").mkdir(parents=True, exist_ok=True)
    (out / "labels").mkdir(parents=True, exist_ok=True)
    (out / "classes.txt").write_text("\n".join(project.classes) + "\n", encoding="utf-8")
    a, b = project.ranges[task_id]
    todo = [k for k in range(a, b) if project.is_reviewed(k)]
    boxes = empty = 0
    for n, k in enumerate(todo):
        if should_stop and should_stop():
            return None
        it = project.items[k]
        name = f"{project.task_of(k)['name']}_f{(it['frame'] if it.get('frame') is not None else k - a):06d}"
        W, H = project.image_size(k)
        lines = [l for l in (yolo_line(p["cls"], *p["box"], W, H) for p in project.boxes(k) if p["source"] != "suggested") if l]
        if not (out / "images" / f"{name}.jpg").exists():
            project.place(k, out / "images" / f"{name}.jpg")
        if project.task == "segment":
            parts, polys = np.zeros((H, W), np.uint8), []
            for p in project.boxes(k):
                if p["source"] == "suggested" or not yolo_line(p["cls"], *p["box"], W, H):
                    continue
                m = project.mask(k, p["obj"])
                poly = mask_polygon(m.astype(bool)) if m is not None else None
                if m is not None:
                    parts[m.astype(bool)] = 255
                else:                                          # a part without an outline: its box
                    x1, y1, x2, y2 = (int(round(v)) for v in p["box"])
                    parts[max(0, y1):y2, max(0, x1):x2] = 255
                if poly is None:
                    x1, y1, x2, y2 = p["box"]
                    poly = np.array([[x1, y1], [x2, y1], [x2, y2], [x1, y2]], float)
                polys.append(polygon_line(p["cls"], poly, W, H))
            (out / "masks").mkdir(exist_ok=True)
            (out / "polygons").mkdir(exist_ok=True)
            Image.fromarray(parts).save(out / "masks" / f"{name}.png")
            (out / "polygons" / f"{name}.txt").write_text("\n".join(polys) + ("\n" if polys else ""))
        (out / "labels" / f"{name}.txt").write_text("\n".join(lines) + ("\n" if lines else ""))
        boxes, empty = boxes + len(lines), empty + (not lines)
        if progress and n % 20 == 0:
            progress(n + 1, len(todo), f"Writing the confirmed frames of task {project.task_of(k)['name']}")
    return {"frames": len(todo), "boxes": boxes, "empty": empty}


def mask_polygon(mask: np.ndarray):
    """One polygon (pixel x, y points) around a part's pixels; several separate pieces are joined into one by
    zero-width bridges between their nearest points (the usual YOLO way). None when nothing is outlined."""
    import cv2
    found, _ = cv2.findContours(mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    pieces = sorted((c[:, 0, :].astype(float) + 0.5 for c in found if len(c) >= 3), key=lambda c: -len(c))
    if not pieces:
        return None
    poly = pieces[0]
    for c in pieces[1:]:
        i, j = np.unravel_index(((poly[:, None] - c[None]) ** 2).sum(-1).argmin(), (len(poly), len(c)))
        poly = np.concatenate([poly[:i + 1], np.roll(c, -j, axis=0), c[j:j + 1], poly[i:]])
    return poly


def polygon_line(c: int, poly, W, H) -> str:
    """YOLO segmentation row: class, then x y of each point as a share of the image."""
    p = np.clip(np.asarray(poly, float) / [W, H], 0, 1)
    return f"{c} " + " ".join(f"{x:.6f} {y:.6f}" for x, y in p)


def line_box(line: str):
    """(class, x1, y1, x2, y2 as shares of the image) of a YOLO box or segmentation row; None if malformed."""
    v = line.split()
    try:
        c, nums = int(float(v[0])), [float(x) for x in v[1:]]
    except (ValueError, IndexError):
        return None
    if len(nums) == 4:
        cx, cy, w, h = nums
        return c, cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2
    if len(nums) < 6 or len(nums) % 2:
        return None
    xs, ys = nums[0::2], nums[1::2]
    return c, min(xs), min(ys), max(xs), max(ys)


def parse_row(line: str):
    """(class, cx, cy, w, h) of one YOLO line; None if malformed."""
    parts = line.split()
    try:
        c, cx, cy, w, h = int(float(parts[0])), *map(float, parts[1:5])
    except (ValueError, IndexError, TypeError):
        return None
    return (c, cx, cy, w, h) if len(parts) >= 5 and w > 0 and h > 0 else None


def read_labels(path, nc: int) -> tuple[list[tuple], int]:
    """Valid rows of a YOLO file and the number of invalid lines (malformed, empty box, unknown class)."""
    rows, bad = [], 0
    for line in Path(path).read_text().splitlines():
        if not line.strip():
            continue
        r = parse_row(line)
        if r is None or not 0 <= r[0] < nc:
            bad += 1
        else:
            rows.append(r)
    return rows, bad


def infer_sampling(names) -> dict:
    """Every-N step, frame offset and naming pattern from `<stem>_f<frame>` names. every is the most common
    gap between consecutive frames of one video (gaps from unlabeled frames do not change it); None when
    most names carry no frame number (e.g. a photo folder), whose files keep their own names."""
    frames, digits = defaultdict(list), Counter()
    for n in names:
        m = FRAME_RE.search(n)
        if m:
            frames[n[:m.start()]].append(int(m.group(1)))
            digits[len(m.group(1))] += 1
    if not names or sum(digits.values()) * 2 <= len(names):
        return {"every": None, "offset": None, "naming": "{name}"}
    steps = Counter(b - a for f in frames.values() for a, b in zip(sorted(f), sorted(f)[1:]) if b > a)
    every = min(s for s, n in steps.items() if n == max(steps.values())) if steps else None
    offset = Counter(x % every for f in frames.values() for x in f).most_common(1)[0][0] if every else None
    return {"every": every, "offset": offset, "naming": f"{{stem}}_f{{frame:0{digits.most_common(1)[0][0]}d}}"}


# ---- analyse --------------------------------------------------------------------------------
def analyse(dataset_dir, resolution: int = 640) -> dict:
    """Classes, box counts, presence and box sizes per class, labeled vs unlabeled images, sampling, and
    warnings about labels that will hurt training or its evaluation."""
    root = Path(dataset_dir)
    classes, items = classes_of(root), source_items(root)
    nc = len(classes)
    boxes, frames, tiny, dups = Counter(), Counter(), Counter(), Counter()
    sizes = defaultdict(list)
    invalid = background = 0
    for it in items:
        if it["label"] is None:
            continue
        rows, bad = read_labels(it["label"], nc)
        invalid += bad
        background += not rows
        with Image.open(it["image"]) as im:
            W, H = im.size
        seen = set()
        for c, cx, cy, w, h in rows:
            key = (c, round(cx, 6), round(cy, 6), round(w, 6), round(h, 6))
            if key in seen:
                dups[c] += 1
                continue
            seen.add(key)
            boxes[c] += 1
            sizes[c].append((w * W, h * H))
            tiny[c] += min(w, h) * resolution < TINY_PX         # each side stretched to the input on its own
        frames.update({c for c, *_ in rows})
    labeled = sum(it["label"] is not None for it in items)
    per_class = {}
    for c, name in enumerate(classes):
        wh = np.array(sizes[c]) if sizes[c] else np.zeros((0, 2))
        stat = lambda a: [round(float(a.min()), 1), round(float(np.median(a)), 1), round(float(a.max()), 1)] if len(a) else None
        per_class[name] = {"boxes": boxes[c], "frames": frames[c], "presence": round(frames[c] / max(labeled, 1), 3),
                           "width_px": stat(wh[:, 0]), "height_px": stat(wh[:, 1]),
                           "tiny": tiny[c], "duplicates": dups[c]}
    sampling = infer_sampling([it["name"] for it in items])
    sampling["image_ext"] = Counter(it["image"].suffix.lower() for it in items).most_common(1)[0][0] if items else ".jpg"

    warn = []
    if sampling["offset"]:
        warn.append(f"source frames start at offset {sampling['offset']} (not a multiple of {sampling['every']}); "
                    f"transfer and projects sample frames 0, {sampling['every']}, {2 * sampling['every']}, ...")
    if labeled < len(items):
        warn.append(f"{len(items) - labeled} image(s) have no label file: treated as unlabeled and left out "
                    "(an empty label file would mean 'checked, nothing there')")
    if invalid:
        warn.append(f"{invalid} label line(s) are invalid (malformed, zero size or class id outside 0-{nc - 1}) "
                    "and are ignored")
    pcs = per_class.items()
    groups = {
        "never labeled, so the model cannot learn them": {n: None for n, pc in pcs if not pc["boxes"]},
        f"with fewer than {FEW_BOXES} boxes": {n: pc["boxes"] for n, pc in pcs if 0 < pc["boxes"] < FEW_BOXES},
        f"in under {FEW_FRAMES:.0%} of the {labeled} labeled frames":
            {n: pc["frames"] for n, pc in pcs if pc["boxes"] and pc["presence"] < FEW_FRAMES},
        f"with tiny boxes, under {TINY_PX} px on the shorter side at {resolution} px input before any parent crop "
        "(a parent crop or a higher resolution helps)": {n: pc["tiny"] for n, pc in pcs if pc["tiny"]},
        "with exact duplicate boxes, dropped for training": {n: pc["duplicates"] for n, pc in pcs if pc["duplicates"]}}
    for text, found in groups.items():
        if found:
            warn.append(f"classes {text}: " + ", ".join(n if v is None else f"{n} ({v})" for n, v in found.items()))
    return {"source": str(root), "classes": classes, "images": len(items), "labeled": labeled,
            "with_boxes": labeled - background, "background": background, "unlabeled": len(items) - labeled,
            "boxes": sum(boxes.values()), "invalid_lines": invalid, "per_class": per_class,
            "mirrored_pairs": mirrored_pairs(classes), "sampling": sampling, "warnings": warn}


# ---- prepare --------------------------------------------------------------------------------
def held_out_flags(items, held_out: float = 0.2) -> list[bool]:
    """time_blocks per video (names ending in _fNNNNNN, grouped by what comes before), so every video of a
    source made of several (e.g. several tasks) is tested; images without frame numbers form one group."""
    flags = []
    for _, group in groupby(items, key=lambda it: it["key"][0] if it["key"][1] >= 0 else ""):
        flags += time_blocks(len(list(group)), held_out)
    return flags


def _inside(row, crop, W: int, H: int) -> bool:
    """A YOLO row's box lies wholly inside crop (pixels)."""
    _, cx, cy, w, h = row
    return (cx - w / 2) * W >= crop[0] and (cy - h / 2) * H >= crop[1] and (cx + w / 2) * W <= crop[2] and \
        (cy + h / 2) * H <= crop[3]


def time_blocks(n: int, held_out: float = 0.2, blocks: int = 10) -> list[bool]:
    """Held-out flags for n frames in time order: whole blocks of neighbouring frames, spread over the
    source, so the test is not near-duplicates of training frames."""
    if not 0 < held_out < 1:
        raise ValueError("held_out must be between 0 and 1")
    blocks = max(2, min(blocks, n))
    k = min(blocks - 1, max(1, round(held_out * blocks)))
    chosen = {int((j + 0.5) * blocks / k) for j in range(k)}
    return [int(i * blocks / n) in chosen for i in range(n)]


def yolo_line(c: int, x1, y1, x2, y2, W, H) -> str | None:
    """YOLO row for a pixel box, clipped to the image; None when nothing is left."""
    x1, y1, x2, y2 = max(0.0, float(x1)), max(0.0, float(y1)), min(float(W), float(x2)), min(float(H), float(y2))
    if x2 <= x1 or y2 <= y1:
        return None
    return f"{c} {(x1 + x2) / 2 / W:.6f} {(y1 + y2) / 2 / H:.6f} {(x2 - x1) / W:.6f} {(y2 - y1) / H:.6f}"


def to_crop(row, crop, W, H) -> str | None:
    """A full-image YOLO row in the coordinates of crop (x1, y1, x2, y2 pixels): clipped, None if outside."""
    c, cx, cy, w, h = row
    X1, Y1, X2, Y2 = crop
    x1, y1 = (cx - w / 2) * W - X1, (cy - h / 2) * H - Y1
    return yolo_line(c, x1, y1, x1 + w * W, y1 + h * H, X2 - X1, Y2 - Y1)


def from_crop(row, crop, W, H) -> str | None:
    """The inverse of to_crop: a row relative to the crop, back in full-image coordinates."""
    c, cx, cy, w, h = row
    X1, Y1, X2, Y2 = crop
    cw, ch = X2 - X1, Y2 - Y1
    x1, y1 = (cx - w / 2) * cw + X1, (cy - h / 2) * ch + Y1
    return yolo_line(c, x1, y1, x1 + w * cw, y1 + h * ch, W, H)


def crop_polygon(line: str, crop, W, H) -> str | None:
    """A full-image YOLO segmentation row in the coordinates of crop (points clipped to it); None if outside."""
    v = line.split()
    p = np.array(v[1:], float).reshape(-1, 2) * [W, H] - [crop[0], crop[1]]
    cw, ch = crop[2] - crop[0], crop[3] - crop[1]
    p = np.clip(p, 0, [cw, ch])
    if np.ptp(p[:, 0]) <= 0 or np.ptp(p[:, 1]) <= 0:
        return None
    return polygon_line(int(float(v[0])), p, cw, ch)


def _save(img: Image.Image, path: Path) -> None:
    jpg = path.suffix.lower() in (".jpg", ".jpeg")
    (img.convert("RGB") if jpg else img).save(path, **({"quality": 95} if jpg else {}))


def write_data_yaml(folder, classes, train: str = "images", val: str = "images") -> None:
    Path(folder, "data.yaml").write_text(f"train: {train}\nval: {val}\n\nnc: {len(classes)}\nnames:\n" +
                                         "".join(f"  {i}: {n}\n" for i, n in enumerate(classes)), encoding="utf-8")


def _recolor_copies(copies, train, n, progress=None, should_stop=None):
    """A copy of each (image, label lines, name, colour, part pixels, object box) with the object painted that
    colour: its outline from SAM 3, prompted by the object's box in that image."""
    from engine import hw
    from engine.segmenter import Segmenter
    seg = Segmenter()
    try:
        for j, (dst, lines, name, color, parts, obj) in enumerate(copies):
            if should_stop and should_stop():
                return None
            small = Image.open(dst).convert("RGB")
            w, h = small.size
            seg.set_image(small)
            body = seg.segment(box=[float(v) for v in obj])[0].astype(bool)
            boxes = [(x1 * w, y1 * h, x2 * w, y2 * h) for _, x1, y1, x2, y2 in (line_box(l) for l in lines)]
            copy = f"{name}_rc_{color}"
            recolor_outside(small, boxes, PALETTE[color], body, parts).save(train / "images" / (copy + ".jpg"), quality=95)
            (train / "labels" / (copy + ".txt")).write_text("\n".join(lines) + ("\n" if lines else ""))
            n["recoloured_copies"] += 1
            if progress and j % 10 == 0:
                progress(j, len(copies), "Painting training copies in other colours")
    finally:
        del seg
        hw.free_gpu_memory()
    return True


def prepare(dataset_dir, out, parent: str | None = None, held_out: float = 0.2, progress=None,
            should_stop=None, recolor: float = 0.0, crop_to_parent: bool = True, polygons: bool = False,
            empty_every: int = 1) -> dict | None:
    """Training set in `out`: train/ and valid/ (images + YOLO labels) and data.yaml. With a parent (text such
    as "engine block"), each image is cut to that object (SAM 3) and its labels move into the crop; with
    crop_to_parent False the images stay whole and the parent is only found for the recoloured copies (`recolor`:
    the share of training frames that also get one). Returns the record also saved as prepared.json (reused when
    source and settings are unchanged); None if stopped. polygons: the labels are the parts' outlines (the
    source's polygons/ folder, from a project with outlines), for a model that outlines parts. empty_every: train on
    1 in N frames without parts (neighbouring video frames of nothing are near copies); held-out frames all kept."""
    root, out = Path(dataset_dir), Path(out)
    if polygons and not (root / "polygons").is_dir():
        raise ValueError(f"{root}: an outline model needs the parts' outlines (polygons/): teach from the tasks of a "
                         "project with outlines")
    classes = classes_of(root)
    items = [it for it in source_items(root) if it["label"] is not None]
    if len(items) < 2:
        raise ValueError(f"{root}: need at least 2 labeled images")
    held = held_out_flags(items, held_out)
    key = hashlib.sha1(json.dumps([str(root.resolve()), parent, held_out, classes, [it["name"] for it in items]]
                                  + ([recolor] if recolor else []) + ([] if crop_to_parent else ["whole"])
                                  + (["polygons"] if polygons else []) + ([f"empty/{empty_every}"] if empty_every > 1 else [])
                                  ).encode()).hexdigest()[:12]
    if (out / "prepared.json").exists():
        rec = json.loads((out / "prepared.json").read_text(encoding="utf-8"))
        if rec.get("key") == key:
            return rec
    shutil.rmtree(out, ignore_errors=True)
    for split in ("train", "valid"):
        (out / split / "images").mkdir(parents=True)
        (out / split / "labels").mkdir(parents=True)
    finder = None
    if parent:
        from engine.parent import ParentFinder, crop_box
        finder = ParentFinder(parent)
    crops, missing, n, last = {}, [], Counter(), None      # last: (video, index, crop) of the latest search
    copies = []                                               # training frames that also get a recoloured copy
    try:
        for k, (it, test) in enumerate(zip(items, held)):
            if should_stop and should_stop():
                return None
            img = Image.open(it["image"])
            W, H = img.size
            crop, obj = (0, 0, W, H), None                    # obj: the parent's box, found or reused
            rows, _ = read_labels(it["label"], len(classes))
            pick = int(hashlib.sha1(it["name"].encode()).hexdigest()[:8], 16)   # the same copies on every run
            copy = recolor and not test and pick % 1000 < recolor * 1000
            if not rows and not test and pick % empty_every:     # an empty training frame left out
                n["empty_left_out"] += 1
                continue
            if finder and not crop_to_parent and copy:            # whole images: the object only for the copy
                obj = finder.find(img.convert("RGB"))
                n["parent_searches"] += 1
            elif finder and crop_to_parent:
                # frames of one video (names _fNNNNNN): the object barely moves between neighbours, so its crop is
                # reused for the next frames; searched again every PARENT_EVERY frames, or when a label of this
                # frame would fall outside it. Pictures without frame numbers are searched one by one.
                video = it["key"][0] if it["key"][1] >= 0 else None
                crop = last[2] if last and video is not None and last[0] == video and k - last[1] < PARENT_EVERY else None
                if crop and not all(_inside(r, crop, W, H) for r in rows):
                    crop = None
                obj = last[3] if crop else None
                if crop is None:
                    box = finder.find(img.convert("RGB"))
                    n["parent_searches"] += 1
                    if box:
                        crop, obj = crop_box(box, W, H, PARENT_MARGIN), box
                        last = (video, k, crop, box)
                    else:
                        crop, last = (0, 0, W, H), None
                        missing.append(it["name"])
            crops[it["name"]] = list(crop)
            n["duplicates_removed"] += len(rows) - len(set(rows))
            lines = []
            for r in dict.fromkeys(rows):                 # exact duplicates dropped, order kept
                c, cx, cy, w, h = r
                x1, y1 = max(0.0, (cx - w / 2) * W), max(0.0, (cy - h / 2) * H)
                x2, y2 = min(W, (cx + w / 2) * W), min(H, (cy + h / 2) * H)
                inside = x1 >= crop[0] and y1 >= crop[1] and x2 <= crop[2] and y2 <= crop[3]
                line = to_crop(r, crop, W, H)
                n["kept" if line and inside else "clipped" if line else "outside_parent"] += 1
                lines += [line] if line else []
            if polygons:                                       # the same parts, outlined, moved into the crop
                lines = [crop_polygon(l, crop, W, H) for l in dict.fromkeys(
                    (root / "polygons" / f"{it['name']}.txt").read_text().splitlines()) if l.strip()]
                lines = [l for l in lines if l]
            split = out / ("valid" if test else "train")
            dst = split / "images" / (it["name"] + it["image"].suffix.lower())
            if crop == (0, 0, W, H):
                shutil.copyfile(it["image"], dst)
            else:
                _save(img.crop(crop), dst)
            (split / "labels" / (it["name"] + ".txt")).write_text("\n".join(lines) + ("\n" if lines else ""))
            if copy and obj:                                   # the object's box in the saved image
                mask = root / "masks" / f"{it['name']}.png"
                ox, oy = crop[0], crop[1]
                copies.append((dst, lines, it["name"], sorted(PALETTE)[pick % len(PALETTE)],
                               np.asarray(Image.open(mask).crop(crop)) > 0 if mask.exists() else None,
                               (obj[0] - ox, obj[1] - oy, obj[2] - ox, obj[3] - oy)))
            if progress and k % 10 == 0:
                progress(k, len(items), "Preparing the training set" + (f" (finding '{parent}')" if parent else ""))
    finally:
        if finder:
            from engine import hw
            del finder
            hw.free_gpu_memory()
    if copies and _recolor_copies(copies, out / "train", n, progress, should_stop) is None:
        return None
    write_data_yaml(out, classes, "train/images", "valid/images")
    total = sum(n[k] for k in ("kept", "clipped", "outside_parent"))
    rec = {"key": key, "source": str(root.resolve()), "parent": parent, "held_out": held_out,
           "train": [it["name"] for it, h in zip(items, held) if not h],
           "valid": [it["name"] for it, h in zip(items, held) if h],
           "boxes": dict(n), "parent_coverage": round(n["kept"] / total, 3) if parent and crop_to_parent and total else None,
           "parent_missing": missing, "crops": crops}
    (out / "prepared.json").write_text(json.dumps(rec), encoding="utf-8")
    return rec


# ---- prove ----------------------------------------------------------------------------------
def load_targets(label: Path, W: int, H: int) -> sv.Detections:
    """The labels as Detections (boxes; outlines give their boxes); data["polygons"]: each row's points in pixels
    (None for a box row)."""
    lines = [l for l in label.read_text().splitlines() if l.strip()] if label.exists() else []
    rows = [(r, l) for r, l in ((line_box(l), l) for l in lines) if r]
    if not rows:
        return sv.Detections(xyxy=np.zeros((0, 4)), class_id=np.zeros(0, int))
    a = np.array([r for r, _ in rows], float)
    polys = np.empty(len(rows), object)                     # one array of points per row (never stacked)
    for k, (_, l) in enumerate(rows):
        polys[k] = np.array(l.split()[1:], float).reshape(-1, 2) * [W, H] if len(l.split()) > 5 else None
    return sv.Detections(xyxy=a[:, 1:] * [W, H, W, H], class_id=a[:, 0].astype(int), data={"polygons": polys})


def mask_ious(pred: sv.Detections, target: sv.Detections, iou: float = 0.5) -> list[tuple[int, float]]:
    """(class, outline IoU) of each labeled outline and the surest prediction of its class whose box overlaps it
    (box IoU at least iou); parts not found are left out (recall counts them)."""
    import cv2
    if pred.mask is None or not len(target) or "polygons" not in target.data:
        return []
    H, W = pred.mask.shape[1:] if len(pred) else (0, 0)
    out, used = [], set()
    for t in range(len(target)):
        poly, c = target.data["polygons"][t], int(target.class_id[t])
        cand = [i for i in np.argsort(-pred.confidence) if int(pred.class_id[i]) == c and i not in used]
        cand = [i for i in cand if sv.box_iou_batch(target.xyxy[t:t + 1], pred.xyxy[i:i + 1])[0, 0] >= iou]
        if poly is None or not cand:
            continue
        used.add(cand[0])
        m = np.zeros((H, W), np.uint8)
        cv2.fillPoly(m, [np.round(poly - 0.5).astype(np.int32)], 1)
        p = pred.mask[cand[0]]
        union = np.logical_or(p, m).sum()
        out.append((c, float(np.logical_and(p, m).sum() / union) if union else 0.0))
    return out


def count_matches(preds, targets, iou: float = 0.5) -> tuple[Counter, Counter, Counter]:
    """Per class true positives, false positives and misses: each label matched at most once, most
    confident prediction first."""
    tp, fp, fn = Counter(), Counter(), Counter()
    for p, t in zip(preds, targets):
        for c in set(p.class_id.tolist()) | set(t.class_id.tolist()):
            pc, tc = p[p.class_id == c], t[t.class_id == c]
            hits = 0
            if len(pc) and len(tc):
                m, used = sv.box_iou_batch(tc.xyxy, pc.xyxy), np.zeros(len(tc), bool)
                order = np.argsort(-pc.confidence) if pc.confidence is not None else range(len(pc))
                for i in order:
                    ious = np.where(used, -1.0, m[:, i])
                    j = int(ious.argmax())
                    if ious[j] >= iou:
                        used[j], hits = True, hits + 1
            tp[c] += hits
            fp[c] += len(pc) - hits
            fn[c] += len(tc) - hits
    return tp, fp, fn


def f1_sweep(preds, targets, thresholds=THRESHOLDS) -> dict[float, float]:
    """Micro F1 over all classes at each confidence threshold."""
    out = {}
    for th in thresholds:
        tp, fp, fn = (sum(c.values()) for c in count_matches([p[p.confidence >= th] for p in preds], targets))
        out[th] = round(2 * tp / max(2 * tp + fp + fn, 1), 4)
    return out


def pick_threshold(sweep: dict) -> float:
    """Threshold with the best micro F1; when several share it, the middle one (safest on a plateau)."""
    best = max(sweep.values())
    tied = sorted(t for t, f in sweep.items() if f >= best - 1e-9)
    return tied[len(tied) // 2]


def repaint_outside(img: Image.Image, det: sv.Detections, tint=(0.25, 0.25, 0.27)) -> Image.Image:
    """Everything outside the labeled boxes repainted in a dark tint, keeping its shading."""
    a = np.asarray(img).astype(np.float32)
    keep = np.zeros(a.shape[:2], bool)
    for x1, y1, x2, y2 in det.xyxy.astype(int):
        keep[max(0, y1):y2, max(0, x1):x2] = True
    painted = a.mean(axis=2, keepdims=True) * np.array(tint, np.float32)
    a[~keep] = painted[~keep]
    return Image.fromarray(a.clip(0, 255).astype(np.uint8))


# Object colours for recoloured copies and the stress test, OpenCV 8-bit Lab (L* x 2.55, a* + 128, b* + 128).
PALETTE = {"white": (235, 128, 131), "silver": (180, 128, 127), "grey": (120, 128, 128), "black": (35, 128, 128),
           "blue": (90, 146, 80), "navy": (55, 140, 96), "green": (110, 96, 154), "yellow": (212, 124, 190),
           "orange": (152, 168, 184), "brown": (88, 142, 150), "red": (112, 184, 160), "beige": (205, 131, 150)}


def recolor_outside(img: Image.Image, boxes, color, region=None, parts=None) -> Image.Image:
    """The object painted another colour, keeping its shading: inside `region` (a bool mask, e.g. the object's
    outline; None = the whole picture) everything but the labeled parts moves to `color` (Lab as in PALETTE). The
    parts keep their own colours, and so do bright pixels right next to them (a lamp's glow) and very dark areas
    (tyres, glass, gaps). boxes: the parts, pixel [x1, y1, x2, y2]; parts: their exact pixels (a bool mask from
    their outlines), kept instead of the whole boxes."""
    import cv2
    a = np.asarray(img.convert("RGB"))
    lab = cv2.cvtColor(a, cv2.COLOR_RGB2LAB).astype(np.float32)
    L = lab[..., 0]
    keep, near = np.zeros(a.shape[:2], np.float32), np.zeros(a.shape[:2], np.float32)
    for x1, y1, x2, y2 in boxes:
        if parts is None:
            keep[max(0, int(y1)):max(0, int(y2)), max(0, int(x1)):max(0, int(x2))] = 1
        m = 0.5 * min(x2 - x1, y2 - y1) + 6                  # the glow: bright pixels close to the part
        near[max(0, int(y1 - m)):max(0, int(y2 + m)), max(0, int(x1 - m)):max(0, int(x2 + m))] = 1
    if parts is not None:
        keep[parts[:keep.shape[0], :keep.shape[1]]] = 1
    body = (keep == 0) if region is None else region & (keep == 0)
    glow = max(170.0, min(245.0, float(np.percentile(L[body], 90)) + 5 if body.any() else 170.0))   # above a white body
    keep = np.maximum(cv2.GaussianBlur(np.maximum(keep, near * (L > glow)), (0, 0), 3), keep)[..., None]   # parts exact
    if region is not None:
        keep = np.maximum(keep, cv2.GaussianBlur((~region).astype(np.float32), (0, 0), 3)[..., None])
    new = np.stack([np.clip(color[0] + (L - np.median(L)) * 0.6, 0, 255),
                    color[1] + (lab[..., 1] - np.median(lab[..., 1])) * 0.15,     # the object's own tint goes,
                    color[2] + (lab[..., 2] - np.median(lab[..., 2])) * 0.15], axis=-1)  # its local variation stays
    new = cv2.cvtColor(new.clip(0, 255).astype(np.uint8), cv2.COLOR_LAB2RGB).astype(np.float32)
    w = (1 - keep) * np.clip((L - 40) / 60, 0, 1)[..., None]   # 0 on the parts and on dark pixels: kept as they are
    return Image.fromarray((a * (1 - w) + new * w).round().clip(0, 255).astype(np.uint8))


def hue_rotate(img: Image.Image, degrees: float = 180) -> Image.Image:
    h, s, v = img.convert("HSV").split()
    shift = int(round(degrees / 360 * 256))
    return Image.merge("HSV", (h.point(lambda x: (x + shift) % 256), s, v)).convert("RGB")


STRESS = {"grayscale": lambda im, t: ImageOps.grayscale(im).convert("RGB"),
          "hue_180": lambda im, t: hue_rotate(im, 180),
          "dark_background": repaint_outside,
          **{f"{c}_object": (lambda c: lambda im, t: recolor_outside(im, t.xyxy, PALETTE[c]))(c)
             for c in ("white", "black", "blue", "yellow")}}


def _map(preds, targets):
    from supervision.metrics import MeanAveragePrecision
    return MeanAveragePrecision().update(preds, targets).compute()


def prove(model, valid_dir, classes, progress=None, should_stop=None) -> dict:
    """Agreement with the source labels on held-out frames: mAP50, mAP50-95, the confidence threshold with
    the best micro F1, recall/precision per class at it, and the colour stress test (Stop skips the rest of it).
    Frames are read in small batches, never all held in memory."""
    from engine import detector
    valid_dir = Path(valid_dir)
    files = sorted(p for p in (valid_dir / "images").iterdir() if p.suffix.lower() in IMAGE_EXTS)
    targets = []
    for f in files:
        with Image.open(f) as im:                            # the size only: nothing decoded
            targets.append(load_targets(valid_dir / "labels" / (f.stem + ".txt"), *im.size))

    outlines = []                                            # (class, IoU) of labeled outlines found

    def predict(change=None, batch=16):
        out = []
        for i in range(0, len(files), batch):
            ims = [Image.open(f).convert("RGB") for f in files[i:i + batch]]
            got = detector.predict(model, [change(im, t) for im, t in zip(ims, targets[i:])] if change else ims,
                                   threshold=0.01)
            for k, d in enumerate(got):
                if d.mask is not None:                         # outlines: measured now, not kept (memory)
                    if not change:
                        outlines.extend(mask_ious(d[d.confidence >= 0.3], targets[i + k]))
                    d.mask = None
            out += got
        return out

    preds = predict()
    m = _map(preds, targets)
    sweep = f1_sweep(preds, targets)
    th = pick_threshold(sweep)
    tp, fp, fn = count_matches([p[p.confidence >= th] for p in preds], targets)
    ap50 = {int(c): float(a[0]) for c, a in zip(m.matched_classes, m.ap_per_class)}
    per_class = {name: {"labels": tp[c] + fn[c], "found": tp[c], "extra": fp[c],
                        "recall": round(tp[c] / (tp[c] + fn[c]), 3) if tp[c] + fn[c] else None,
                        "precision": round(tp[c] / (tp[c] + fp[c]), 3) if tp[c] + fp[c] else None,
                        "AP50": round(ap50[c], 3) if c in ap50 else None}
                 for c, name in enumerate(classes)}
    TP, FP, FN = sum(tp.values()), sum(fp.values()), sum(fn.values())
    stress = {}
    for k, (name, fn_) in enumerate(STRESS.items()):
        if should_stop and should_stop():
            break
        if progress:
            progress(k, len(STRESS), f"Colour stress test: {name}")
        vm = _map(predict(fn_), targets)
        stress[name] = {"mAP50": round(float(vm.map50), 3), "drop": round(100 * float(m.map50 - vm.map50), 1)}
    iou_c = defaultdict(list)
    for c, v in outlines:
        iou_c[c].append(v)
    for c, name in enumerate(classes):
        if iou_c[c]:
            per_class[name]["outline_IoU"] = round(float(np.mean(iou_c[c])), 3)
    return {"frames": len(files), "labels": TP + FN, "mAP50": round(float(m.map50), 3),
            "outline_IoU": round(float(np.mean([v for _, v in outlines])), 3) if outlines else None,
            "mAP50_95": round(float(m.map50_95), 3), "threshold": th, "f1_sweep": sweep,
            "f1": sweep[th], "recall": round(TP / max(TP + FN, 1), 3), "precision": round(TP / max(TP + FP, 1), 3),
            "per_class": per_class, "stress": stress}


# ---- run folder -----------------------------------------------------------------------------
def _write_json(path: Path, data) -> None:
    path.write_text(json.dumps(data, indent=1), encoding="utf-8")


def _train_step(run_dir: Path, prep: dict, size, epochs, resolution, aug, progress, should_stop) -> Path | None:
    """Train into run_dir/model, or reuse a finished model trained with the same data and settings, or
    resume an interrupted one from its last epoch."""
    from engine import detector
    out = run_dir / "model"
    params = {"dataset": prep["key"], "size": size, "epochs": epochs, "resolution": resolution, "aug": aug}
    done, started = out / "trained.json", out / "started.json"
    if done.exists() and json.loads(done.read_text())["params"] == params and detector.best_checkpoint(out):
        return detector.best_checkpoint(out)
    resume = None
    if started.exists() and json.loads(started.read_text()) == params:
        resume = next((p for p in (out / "last.ckpt", *sorted(out.glob("checkpoint_*.ckpt"))) if p.exists()), None)
    if resume is None:
        shutil.rmtree(out, ignore_errors=True)
    out.mkdir(parents=True, exist_ok=True)
    _write_json(started, params)
    t = time.perf_counter()
    ckpt = detector.train(run_dir / "dataset", out, size, epochs, resolution, aug, resume, progress, should_stop)
    if ckpt is None:
        return None
    _write_json(done, {"params": params, "checkpoint": ckpt.name, "minutes": round((time.perf_counter() - t) / 60, 1),
                       "resumed_from": resume.name if resume else None})
    for f in out.glob("*.ckpt"):             # resume state only (~0.5 GB each); the .pth weights stay
        f.unlink()
    return ckpt


def teach(dataset_dir, run_dir, parent: str | None = None, size: str = "small", epochs: int = 30,
          resolution: int = 640, held_out: float = 0.2, aug: str = "strong", progress=None,
          should_stop=None, recolor: float = 0.0, crop_to_parent: bool = True, stage: str = "all",
          empty_every: int = 1) -> dict:
    """Analyse, prepare, train and prove; writes settings.json, report.json and report.md into run_dir and
    returns the report ({"status": "stopped", ...} when should_stop ended it early). A "seg-" size also outlines
    the parts (trained on the source's polygons/). To train on another machine (e.g. a cloud GPU): stage "prepare"
    stops once run_dir holds analysis.json and dataset/; copy run_dir there and call teach(None, run_dir, ...,
    stage="train") with the same settings: it trains and proves from them."""
    from engine import detector, hw
    if stage not in ("all", "prepare", "train"):
        raise ValueError(f"unknown stage {stage!r}")
    if size not in detector.SIZES:
        raise ValueError(f"unknown model size {size!r}; choose one of {', '.join(detector.SIZES)}")
    detector.check_resolution(resolution, size)
    detector.aug_config([], aug)
    run_dir = Path(run_dir)
    run_dir.mkdir(parents=True, exist_ok=True)
    say = progress or (lambda *a: None)
    if stage == "train":
        analysis = json.loads((run_dir / "analysis.json").read_text(encoding="utf-8"))
        prep = json.loads((run_dir / "dataset" / "prepared.json").read_text(encoding="utf-8"))
        dataset_dir = Path(analysis["source"])
    else:
        dataset_dir = Path(dataset_dir).resolve()
        say(0, 4, "Analysing the source labels")
        analysis = analyse(dataset_dir, resolution)
        _write_json(run_dir / "analysis.json", analysis)
        say(1, 4, "Preparing the training set")
        prep = prepare(dataset_dir, run_dir / "dataset", parent, held_out, progress, should_stop, recolor,
                       crop_to_parent, polygons=detector.is_seg(size), empty_every=empty_every)
        if prep is None:
            return {"status": "stopped", "step": "prepare", "run_dir": str(run_dir)}
        if stage == "prepare":
            return {"status": "prepared", "run_dir": str(run_dir), "train_frames": len(prep["train"]),
                    "held_out_frames": len(prep["valid"]), "boxes": prep["boxes"]}
    say(2, 4, "Training")
    ckpt = _train_step(run_dir, prep, size, epochs, resolution, aug, progress, should_stop)
    if ckpt is None:
        return {"status": "stopped", "step": "train", "run_dir": str(run_dir)}
    say(3, 4, "Proving on held-out frames")
    model = detector.load(ckpt, size, resolution)
    try:
        proof = prove(model, run_dir / "dataset" / "valid", analysis["classes"], progress, should_stop)
    finally:
        del model
        hw.free_gpu_memory()

    classes, sampling = analysis["classes"], analysis["sampling"]
    worst = max((s["drop"] for s in proof["stress"].values()), default=0.0)
    targets = {"held-out mAP50": {"value": proof["mAP50"], "target": f">= {TARGETS['mAP50']:.2f}",
                                  "pass": proof["mAP50"] >= TARGETS["mAP50"]},
               "recall": {"value": proof["recall"], "target": f">= {TARGETS['recall']:.2f}",
                          "pass": proof["recall"] >= TARGETS["recall"]},
               "colour stress drop": {"value": worst, "target": f"<= {TARGETS['stress_drop']:.0f} points",
                                      "pass": worst <= TARGETS["stress_drop"]}}
    warnings = list(analysis["warnings"])
    skipped = [n for n in STRESS if n not in proof["stress"]]
    if skipped:
        warnings.append(f"the colour stress test was stopped early; not run: {', '.join(skipped)}")
    if parent and prep["parent_coverage"] is not None and prep["parent_coverage"] < 0.9:
        warnings.append(f"only {prep['parent_coverage']:.0%} of labeled boxes lie wholly inside the '{parent}' crop: "
                        "check the parent text")
    if prep["parent_missing"]:
        warnings.append(f"'{parent}' was not found in {len(prep['parent_missing'])} image(s); they were used uncropped")
    unmeasured = [n for n, pc in proof["per_class"].items() if analysis["per_class"][n]["boxes"] and not pc["labels"]]
    if unmeasured:
        warnings.append(f"classes with no held-out labels, so their recall is not measured: {', '.join(unmeasured)}")
    low = [f"{n} ({pc['recall']:.2f})" for n, pc in proof["per_class"].items()
           if pc["recall"] is not None and pc["recall"] < TARGETS["recall"]]
    if low:
        warnings.append(f"classes with held-out recall under {TARGETS['recall']:.2f} (check how consistently the "
                        f"source labels them): {', '.join(low)}")
    settings = {"classes": classes, "parent": parent if crop_to_parent else None, "object": parent,   # no parent:
                "recolor": recolor, "parent_margin": PARENT_MARGIN, "size": size,                   # whole frames
                "resolution": resolution, "threshold": proof["threshold"], "every": sampling["every"],
                "naming": sampling["naming"], "image_ext": sampling["image_ext"],
                "presence": {n: pc["presence"] for n, pc in analysis["per_class"].items()},
                "checkpoint": ckpt.relative_to(run_dir).as_posix(), "source": str(dataset_dir),
                "created": time.strftime("%Y-%m-%d %H:%M:%S")}
    report = {"status": "done", "run_dir": str(run_dir), "source": str(dataset_dir),
              "knowledge_score": round(100 * proof["mAP50"], 1), "passed": all(t["pass"] for t in targets.values()),
              "targets": targets, "held_out": proof, "warnings": warnings, "checkpoint": str(ckpt),
              "training": json.loads((run_dir / "model" / "trained.json").read_text()),
              "prepare": {k: prep[k] for k in ("parent", "held_out", "boxes", "parent_coverage")} |
                         {"train_frames": len(prep["train"]), "held_out_frames": len(prep["valid"]),
                          "parent_missing": len(prep["parent_missing"])},
              "analysis": {k: v for k, v in analysis.items() if k != "warnings"}, "settings": settings}
    _write_json(run_dir / "settings.json", settings)
    _write_json(run_dir / "report.json", report)
    (run_dir / "report.md").write_text(report_md(report), encoding="utf-8")
    say(4, 4, "Done")
    return report


def report_md(r: dict) -> str:
    """The report as a page a person reads: verdict first, then per class, stress test and warnings."""
    p, a, s, ho = r["prepare"], r["analysis"], r["settings"], r["held_out"]
    fmt = lambda v: "-" if v is None else f"{v:.2f}" if isinstance(v, float) else str(v)
    out = [f"# Teach report: {Path(r['source']).name}", "",
           f"**Knowledge score: {r['knowledge_score']:.1f} / 100** (held-out mAP50: agreement with the source "
           f"labels on {ho['frames']} frames the model never saw). **{'PASS' if r['passed'] else 'FAIL'}** "
           "against the targets.", "",
           "| Target | Value | Required | Result |", "|---|---|---|---|"]
    out += [f"| {k} | {fmt(t['value'])} | {t['target']} | {'pass' if t['pass'] else 'FAIL'} |" for k, t in r["targets"].items()]
    out += ["", f"mAP50-95 {ho['mAP50_95']:.3f} · confidence threshold {ho['threshold']:.2f} (best micro F1 "
            f"{ho['f1']:.3f}) · recall {ho['recall']:.3f} · precision {ho['precision']:.3f}"
            + (f" · outline IoU {ho['outline_IoU']:.3f} (predicted vs labeled outlines of the parts found)"
               if ho.get("outline_IoU") is not None else ""), "",
            "## Per class (held-out frames, at the threshold)", "",
            "| Class | Source boxes | In % of frames | Held-out labels | Recall | Precision | AP50 |",
            "|---|---|---|---|---|---|---|"]
    for name, pc in ho["per_class"].items():
        src = a["per_class"][name]
        low = pc["recall"] is not None and pc["recall"] < TARGETS["recall"]
        recall = f"**{fmt(pc['recall'])}**" if low else fmt(pc["recall"])
        out.append(f"| {name} | {src['boxes']} | {src['presence']:.0%} | {pc['labels']} | {recall} | "
                   f"{fmt(pc['precision'])} | {fmt(pc['AP50'])} |" + (f" outline IoU {pc['outline_IoU']:.3f}"
                                                                        if pc.get("outline_IoU") is not None else ""))
    out += ["", "## Colour stress test (same held-out frames)", "", "| Variant | mAP50 | Drop (points) |", "|---|---|---|"]
    out += [f"| {k} | {v['mAP50']:.3f} | {v['drop']:.1f} |" for k, v in ho["stress"].items()]
    out += ["", "## Warnings", ""] + ([f"- {w}" for w in r["warnings"]] or ["- none"])
    every = f"1 frame in {s['every']}" if s["every"] else "not a frame sequence (files keep their names)"
    out += ["", "## Source and settings", "",
            f"- Source: `{r['source']}`: {a['images']} images, {a['labeled']} labeled ({a['background']} empty = "
            f"background), {a['unlabeled']} without a label file, {a['boxes']} boxes, {len(a['classes'])} classes",
            f"- Sampling: {every}; file names `{s['naming']}{s['image_ext']}`",
            f"- Parent object: {s['parent'] or 'none (whole image)'}"
            + (f"; {p['parent_coverage']:.0%} of labeled boxes wholly inside" if p["parent_coverage"] is not None else ""),
            f"- Split: {p['train_frames']} train / {p['held_out_frames']} held-out frames, time blocks",
            f"- Model: RF-DETR {s['size']}, {s['resolution']} px, horizontal flip "
            f"{'off (left/right classes)' if a['mirrored_pairs'] else 'on'}; {r['training']['minutes']} min training",
            f"- Checkpoint: `{r['checkpoint']}`", ""]
    return "\n".join(out)

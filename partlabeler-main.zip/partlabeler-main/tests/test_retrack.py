"""Re-tracking after a fix (track with redo) and clearing parts after a frame (engine/api.py), with a stand-in
tracker that carries the start frame's boxes to every frame it is asked for."""
from engine import api
from engine.api import Session
from engine.project import Project
from tests.test_project import CLASSES, video  # noqa: F401  (fixture)


class FakeTracker:
    def track(self, project, start, count, on_item, should_stop, direction=1, masks=False, only=None):
        parts = {b["obj"]: (b["cls"], b["box"], 0.9) for b in project.boxes(start)
                 if b["source"] != "suggested" and (not only or b["cls"] in only)}
        span = range(start + 1, start + count + 1) if direction > 0 else range(start - 1, start - count - 1, -1)
        for k in span:
            on_item(k, dict(parts))
        return len(span)


def classes(p, item):
    return sorted(b["cls"] for b in p.boxes(item))


def labeled(tmp_path, video, monkeypatch):
    monkeypatch.setitem(api._MODELS, "track", FakeTracker())
    p = Project.create(tmp_path / "proj", CLASSES, video=video, every=2)      # 10 frames
    s = Session(p, lambda m: None)
    s.call({"type": "box", "item": 0, "cls": 0, "box": [1, 1, 10, 10]})
    s.call({"type": "box", "item": 0, "cls": 1, "box": [20, 20, 30, 30]})
    s.call({"type": "track", "item": 0, "count": 5})                         # frames 1–5 get both parts
    return p, s


def test_retrack_carries_a_fix_on_and_keeps_peoples_work(tmp_path, video, monkeypatch):
    p, s = labeled(tmp_path, video, monkeypatch)
    s.call({"type": "box", "item": 3, "cls": 2, "box": [40, 5, 50, 15]})       # a person's own box on frame 3
    s.call({"type": "review", "item": 4})                                     # frame 4 confirmed
    s.call({"type": "delete", "item": 0, "obj": next(b["obj"] for b in p.boxes(0) if b["cls"] == 1)})
    s.call({"type": "track", "item": 0, "count": 2})
    assert classes(p, 2) == [0, 1]                                            # plain tracking leaves the stale part
    said = s.call({"type": "track", "item": 0, "count": -1, "redo": True})
    assert any("Re-tracked 9 frames ahead" in x for x in said)
    assert classes(p, 2) == [0] and classes(p, 3) == [0, 2]                   # stale part gone, own box kept
    assert classes(p, 4) == [0, 1] and classes(p, 9) == [0]                   # confirmed frame untouched; empty filled
    s.call({"type": "undo"})
    assert classes(p, 2) == [0, 1] and classes(p, 9) == []


def test_clear_parts_after_a_frame_by_class_range_and_confirmed(tmp_path, video, monkeypatch):
    p, s = labeled(tmp_path, video, monkeypatch)
    s.call({"type": "review", "item": 4})
    said = s.call({"type": "clear", "item": 1, "classes": [1], "count": -1})
    assert "Cleared 3 parts from 3 frames" in said[-1]
    assert classes(p, 1) == [0, 1] and classes(p, 2) == [0] and classes(p, 4) == [0, 1] and classes(p, 5) == [0]
    s.call({"type": "clear", "item": 1, "count": 1})                          # every class, the next frame only
    assert classes(p, 2) == [] and classes(p, 3) == [0]
    s.call({"type": "clear", "item": 1, "count": -1, "confirmed": True})
    assert classes(p, 4) == [] and all(classes(p, k) == [] for k in range(2, 10)) and classes(p, 1) == [0, 1]
    s.call({"type": "undo"})
    assert classes(p, 4) == [0, 1] and classes(p, 3) == [0]
    assert s.call({"type": "clear", "item": 9, "count": -1}) == ["No frames after this one"]


def test_confirmed_frames_steer_tracking_and_suggest_sees_every_class(tmp_path, video, monkeypatch):
    from engine.suggest import Suggester
    p, s = labeled(tmp_path, video, monkeypatch)
    obj = next(b["obj"] for b in p.boxes(0) if b["cls"] == 0)
    assert p.anchors(obj) == [0]
    s.call({"type": "review", "item": 3})                                     # a person checked the tracked frame 3
    assert p.anchors(obj) == [0, 3]
    s.call({"type": "box", "item": 7, "cls": 2, "box": [2, 2, 8, 8]})         # class 2 only on frame 7
    for k in range(4, 10):
        s.call({"type": "review", "item": k})
    refs = Suggester._refs(p, 1, max_refs=4)                                 # few refs: every class still in
    assert 7 in refs and len(refs) == 4


def test_track_some_classes_alone(tmp_path, video, monkeypatch):
    p, s = labeled(tmp_path, video, monkeypatch)                            # classes 0 and 1 tracked onto 1-5
    p.put(3, 90, 2, [40, 40, 50, 50], "imported", 0.9)                     # a model's class-2 part on frame 3
    p.put(4, 91, 1, [60, 60, 70, 70])                                       # a person's own class-1 box on frame 4
    s.call({"type": "review", "item": 5})
    s.call({"type": "box", "item": 1, "cls": 2, "box": [5, 5, 15, 15]})    # class 2 drawn on frame 1
    moved = {k: [b["box"] for b in p.boxes(k) if b["cls"] == 0] for k in range(2, 6)}
    said = s.call({"type": "track", "item": 1, "count": -1, "classes": [2]})
    assert "Tracked grill 8 frames ahead" in said[-1]
    assert [b["box"] for b in p.boxes(3) if b["cls"] == 2] == [[5, 5, 15, 15]]   # the model's part replaced
    assert {k: [b["box"] for b in p.boxes(k) if b["cls"] == 0] for k in range(2, 6)} == moved   # others untouched
    assert sorted(b["cls"] for b in p.boxes(4)) == [0, 1, 1, 2]            # the person's own box stays
    assert 2 not in [b["cls"] for b in p.boxes(5)]                         # confirmed: left alone ...
    s.call({"type": "track", "item": 1, "count": -1, "classes": [2], "confirmed": True})
    assert sorted(b["cls"] for b in p.boxes(5)) == [0, 1, 2] and p.is_reviewed(5)   # ... unless asked
    said = s.call({"type": "track", "item": 7, "count": 2, "classes": [1]})   # frame 7 has no class 1
    assert "Nothing to track" in said[-1]


def test_swap_classes(tmp_path, video, monkeypatch):
    p, s = labeled(tmp_path, video, monkeypatch)                            # classes 0 and 1 on frames 0-5
    s.call({"type": "box", "item": 2, "cls": 2, "box": [40, 5, 50, 15]})       # class 2 stays out of it
    s.call({"type": "review", "item": 1})
    box_of = lambda k, c: next(b["box"] for b in p.boxes(k) if b["cls"] == c)
    said = s.call({"type": "swap_classes", "item": 1, "src": 0, "dst": 1, "both": True})
    assert "Swapped left_drl and right_drl on 10 parts" in said[-1]          # frames 1-5, the confirmed one too
    assert box_of(0, 0) == [1, 1, 10, 10] and box_of(1, 0) == [20, 20, 30, 30] and classes(p, 2) == [0, 1, 2]
    s.call({"type": "undo"})
    assert box_of(1, 0) == [1, 1, 10, 10]
    s.call({"type": "swap_classes", "item": 3, "src": 0, "dst": 2, "scope": "task"})   # one way only
    assert classes(p, 0) == [1, 2] and classes(p, 2) == [1, 2, 2]
    s.call({"type": "swap_classes", "item": 3, "src": 2, "dst": 0, "scope": "frame"})
    assert classes(p, 3) == [0, 1] and classes(p, 4) == [1, 2]


def test_part_ids_stay_unique_while_threads_add_parts(tmp_path, video):
    """A job reserving ids while a person draws: every id is handed out once (they collided before)."""
    import threading
    p = Project.create(tmp_path / "proj", CLASSES, video=video, every=2)
    got, lock = [], threading.Lock()

    def take(n):
        for _ in range(n):
            o = p.new_obj()                                     # like a person drawing: take an id, then save
            with lock:
                got.append(o)
            p.put(0, o, 0, [1, 1, 5, 5])
    first = p.new_obj(10)                                       # a job reserving a block
    threads = [threading.Thread(target=take, args=(50,)) for _ in range(3)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert len(set(got)) == 150 and not set(got) & set(range(first, first + 10))


def test_tracker_choice_and_fallback(tmp_path, monkeypatch):
    from engine import tracker as T
    monkeypatch.setenv("PARTLABELER_CONFIG", str(tmp_path))                  # no app.json: the default
    monkeypatch.delenv("PARTLABELER_TRACKER", raising=False)
    monkeypatch.setattr(T, "Tracker", lambda: "sam3")
    monkeypatch.setattr(T, "Tracker31", lambda: "sam3.1")
    assert T.make_tracker() == "sam3"
    (tmp_path / "app.json").write_text('{"tracker": "sam3.1"}')
    assert T.make_tracker() == "sam3.1"

    def offline():
        raise OSError("no internet for the first download")
    monkeypatch.setattr(T, "Tracker31", offline)
    assert T.make_tracker() == "sam3"


def test_tracking_writes_while_a_person_confirms(tmp_path, video):
    """Tracking writes frames from its job thread while the request thread confirms others (both mark items
    touched with the same statement). One unlocked connection failed with "bad parameter or other API misuse"."""
    import threading
    p = Project.create(tmp_path / "proj", CLASSES, video=video, every=2)
    errors = []

    def run(fn):
        try:
            for i in range(400):
                fn(i % len(p.items))
        except Exception as e:                                 # noqa: BLE001  (reported below)
            errors.append(e)
    threads = [threading.Thread(target=run, args=(lambda k: p.put_tracked(k, {1: (0, [1, 1, 9, 9], 0.9)}),)),
               threading.Thread(target=run, args=(lambda k: p.set_reviewed(k, k % 2 == 0),)),
               threading.Thread(target=run, args=(lambda k: p.statuses(),))]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert not errors, errors[:1]

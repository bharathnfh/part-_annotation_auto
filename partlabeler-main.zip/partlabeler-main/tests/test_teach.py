"""Teach & Transfer logic and the CLI: fast, CPU only, no model weights (the detector is faked)."""
import json
import shutil

import numpy as np
import pytest
import supervision as sv
from PIL import Image
from typer.testing import CliRunner

from engine import detector, hw
from engine.cli import app
from engine.teach import (analyse, f1_sweep, from_crop, infer_sampling, parse_row, pick_threshold, prepare,
                          prove, source_items, teach, time_blocks, to_crop)
from engine.transfer import frames_to_check, transfer
from tests.test_project import CLASSES, video  # noqa: F401  (fixture)

runner = CliRunner()
BOXES = np.array([[24, 48, 56, 72], [104, 48, 136, 72]], float)


def make_source(root, n=20, every=5):
    (root / "images").mkdir(parents=True)
    (root / "labels").mkdir()
    (root / "classes.txt").write_text("left_lamp\nright_lamp\nbolt\n")
    for k in range(n):
        name = f"cam_f{k * every:06d}"
        Image.new("RGB", (160, 120), (k * 12 % 255, 90, 60)).save(root / "images" / f"{name}.jpg")
        (root / "labels" / f"{name}.txt").write_text("0 0.25 0.5 0.2 0.2\n1 0.75 0.5 0.2 0.2\n")
    return root


def fake_predict(model, images, threshold=0.5, batch=8):
    """The two labels of make_source, at the same relative place in any image."""
    def one(im):
        W, H = im.size
        xyxy = np.array([[0.15, 0.4, 0.35, 0.6], [0.65, 0.4, 0.85, 0.6]]) * [W, H, W, H]
        return sv.Detections(xyxy=xyxy, class_id=np.array([0, 1]), confidence=np.array([0.9, 0.8]))
    return [one(im) for im in images] if isinstance(images, list) else one(images)


@pytest.fixture
def fake_detector(monkeypatch):
    monkeypatch.setattr(detector, "load", lambda *a, **k: object())
    monkeypatch.setattr(detector, "predict", fake_predict)
    monkeypatch.setattr(hw, "free_gpu_memory", lambda: None)


def runs(flags):
    out, start = [], None
    for i, f in enumerate(flags + [False]):
        if f and start is None:
            start = i
        if not f and start is not None:
            out.append((start, i - 1))
            start = None
    return out


def test_time_blocks_are_whole_blocks_spread_over_the_video():
    flags = time_blocks(717, 0.2)
    assert 0.18 < sum(flags) / 717 < 0.22
    (a0, a1), (b0, b1) = runs(flags)                       # two separate blocks of neighbouring frames
    assert a1 < 717 / 2 < b0 and b0 - a1 > 100
    for n in (2, 5, 12, 40):
        assert any(time_blocks(n)) and not all(time_blocks(n))
    with pytest.raises(ValueError):
        time_blocks(10, 0)


def test_parent_search_reuses_the_crop_along_a_video(tmp_path, monkeypatch):
    import engine.parent as parent
    from PIL import Image
    from engine.teach import prepare
    calls = []

    class Finder:                                          # the "car" sits at the same place in every frame
        def __init__(self, text):
            pass

        def find(self, img):
            calls.append(1)
            return (20, 20, 80, 80)
    monkeypatch.setattr(parent, "ParentFinder", Finder)
    src = tmp_path / "src"
    (src / "images").mkdir(parents=True)
    (src / "labels").mkdir()
    (src / "classes.txt").write_text("lamp\n")
    for f in range(8):
        Image.new("RGB", (100, 100)).save(src / "images" / f"cam_f{f * 5:06d}.jpg")
        (src / "labels" / f"cam_f{f * 5:06d}.txt").write_text("0 0.5 0.5 0.1 0.1\n" if f != 6 else "0 0.05 0.05 0.04 0.04\n")
    rec = prepare(src, tmp_path / "out", parent="car")
    # searched on frames 0 and 4, and on frame 6, whose label lies outside the reused crop
    assert len(calls) == 3 and rec["boxes"]["parent_searches"] == 3


def test_recolor_keeps_the_parts_and_repaints_around_them():
    import numpy as np
    from PIL import Image
    from engine.teach import PALETTE, recolor_outside
    a = np.zeros((120, 160, 3), np.uint8)
    a[:] = (180, 30, 30)                                   # a red object
    a[50:70, 60:100] = (255, 170, 0)                         # an amber lamp
    a[100:, :40] = (10, 10, 10)                              # a tyre
    out = np.asarray(recolor_outside(Image.fromarray(a), [(60, 50, 100, 70)], PALETTE["white"])).astype(int)
    assert (abs(out[55:65, 70:90] - a[55:65, 70:90].astype(int)) <= 2).all()       # the lamp untouched
    assert out[10, 10].min() > 200 and np.ptp(out[10, 10]) < 30                    # the body now white
    assert out[110, 10].max() < 40                                                  # the tyre still dark
    region = np.zeros((120, 160), bool)
    region[:, 80:] = True                                    # only the right half is the object
    out = np.asarray(recolor_outside(Image.fromarray(a), [(60, 50, 100, 70)], PALETTE["white"], region)).astype(int)
    assert (abs(out[10, 10] - a[10, 10].astype(int)) <= 2).all() and out[10, 150].min() > 200
    parts = np.zeros((120, 160), bool)
    parts[55:65, 65:95] = True                               # the lamp's outline, smaller than its box
    b = a.copy()
    b[50:55, 60:100] = (180, 30, 30)                          # paint inside the box, around the outline
    out = np.asarray(recolor_outside(Image.fromarray(b), [(60, 50, 100, 70)], PALETTE["blue"], None, parts)).astype(int)
    assert (out[56:64, 70:90] == b[56:64, 70:90]).all() and out[51, 80, 2] > out[51, 80, 0]   # paint in the box: blue


def test_recoloured_copies_with_and_without_the_crop(tmp_path, monkeypatch):
    import numpy as np
    import engine.parent as parent
    import engine.segmenter as segmenter
    from PIL import Image
    from engine.teach import prepare
    searched, prompts = [], []

    class Finder:
        def __init__(self, text):
            pass

        def find(self, img):
            searched.append(1)
            return (20, 20, 80, 80)

    class Seg:                                             # SAM 3 stand-in: the object is its box
        def set_image(self, img):
            self.size = img.size

        def segment(self, box):
            prompts.append([round(v) for v in box])
            m = np.zeros(self.size[::-1], bool)
            x1, y1, x2, y2 = (int(v) for v in box)
            m[y1:y2, x1:x2] = True
            return m, 1.0
    monkeypatch.setattr(parent, "ParentFinder", Finder)
    monkeypatch.setattr(segmenter, "Segmenter", Seg)
    src = tmp_path / "src"
    (src / "images").mkdir(parents=True)
    (src / "labels").mkdir()
    (src / "classes.txt").write_text("lamp\n")
    for f in range(10):
        Image.new("RGB", (100, 100), (180, 30, 30)).save(src / "images" / f"cam_f{f * 5:06d}.jpg")
        (src / "labels" / f"cam_f{f * 5:06d}.txt").write_text("0 0.5 0.5 0.1 0.1\n")
    whole = prepare(src, tmp_path / "whole", parent="car", recolor=1.0, crop_to_parent=False)
    copies = sorted((tmp_path / "whole" / "train" / "images").glob("*_rc_*.jpg"))
    assert whole["boxes"]["recoloured_copies"] == len(copies) == len(whole["train"]) > 0
    assert Image.open(copies[0]).size == (100, 100) and len(searched) == len(copies)   # whole images; searched for copies only
    assert prompts[0] == [20, 20, 80, 80] and whole["parent_coverage"] is None
    searched.clear(), prompts.clear()
    cropped = prepare(src, tmp_path / "crop", parent="car", recolor=1.0)
    assert cropped["boxes"]["recoloured_copies"] > 0
    assert prompts[0] == [8, 8, 68, 68]           # the object's box inside the crop (crop starts at 20 - 0.12 * 60)


def test_every_video_of_a_source_is_tested():
    from engine.teach import held_out_flags
    items = [{"key": (v, f)} for v, n in (("3", 500), ("5", 100), ("7", 20)) for f in range(0, 5 * n, 5)]
    flags = held_out_flags(items)
    for v in ("3", "5", "7"):
        mine = [h for it, h in zip(items, flags) if it["key"][0] == v]
        assert 0.1 < sum(mine) / len(mine) < 0.3                             # each video: about 20% held out
    photos = [{"key": (f"img{i}", -1)} for i in range(30)]                  # no frame numbers: one group
    assert 0 < sum(held_out_flags(photos)) < 30


def test_prepare_splits_by_time_without_leakage(tmp_path):
    src = make_source(tmp_path / "src", n=30)
    (src / "images" / "cam_f000003.jpg").write_bytes((src / "images" / "cam_f000000.jpg").read_bytes())  # no label
    rec = prepare(src, tmp_path / "ds", held_out=0.2)
    assert set(rec["train"]).isdisjoint(rec["valid"]) and len(rec["train"]) + len(rec["valid"]) == 30
    frames = [int(n[-6:]) for n in rec["valid"]]
    assert len(runs([k * 5 in frames for k in range(30)])) == 2 and min(frames) < 75 < max(frames)
    on_disk = {s: {p.stem for p in (tmp_path / "ds" / s / "images").iterdir()} for s in ("train", "valid")}
    assert on_disk == {"train": set(rec["train"]), "valid": set(rec["valid"])}
    assert (tmp_path / "ds/valid/labels" / f"{rec['valid'][0]}.txt").read_text().count("\n") == 2
    assert prepare(src, tmp_path / "ds", held_out=0.2) == rec                     # complete: reused


def test_items_in_numeric_frame_order(tmp_path):
    (tmp_path / "images").mkdir()
    for n in ("v_f10", "v_f5", "v_f100", "photo"):
        Image.new("RGB", (8, 8)).save(tmp_path / "images" / f"{n}.png")
    assert [it["name"] for it in source_items(tmp_path)] == ["photo", "v_f5", "v_f10", "v_f100"]


def test_yolo_crop_round_trip():
    W, H, crop = 1920, 1080, (300, 200, 1500, 1000)
    row = parse_row("3 0.400000 0.550000 0.100000 0.080000")
    inner = parse_row(to_crop(row, crop, W, H))
    assert inner[0] == 3 and inner[3] == pytest.approx(0.1 * W / 1200, abs=1e-6)
    back = parse_row(from_crop(inner, crop, W, H))
    assert back[0] == 3 and np.allclose(back[1:], row[1:], atol=1e-5)
    assert to_crop(parse_row("0 0.05 0.05 0.04 0.04"), crop, W, H) is None           # outside the parent: dropped
    edge = parse_row(to_crop(parse_row("0 0.16 0.5 0.04 0.1"), crop, W, H))          # straddles it: clipped
    assert edge[1] - edge[3] / 2 == pytest.approx(0, abs=1e-6)


def test_analysis_counts_and_warnings(tmp_path):
    root = tmp_path / "src"
    (root / "images").mkdir(parents=True)
    (root / "labels").mkdir()
    (root / "classes.txt").write_text("left_drl\nright_drl\nbolt\nnut\n")
    labels = ["0 0.3 0.5 0.2 0.2\n1 0.7 0.5 0.2 0.2\n2 0.5 0.8 0.01 0.1\n",      # bolt: tiny (6.4 px at 640)
              "0 0.3 0.5 0.2 0.2\n1 0.7 0.5 0.2 0.2\n1 0.7 0.5 0.2 0.2\n",      # exact duplicate
              "0 0.3 0.5 0.2 0.2\n1 0.7 0.5 0.2 0.2\n9 0.5 0.5 0.1 0.1\nabc\n",  # two invalid lines
              "0 0.3 0.5 0.2 0.2\n2 0.5 0.5 0.1 0.1\n",
              ""]                                                                  # checked background
    for k in range(6):
        Image.new("RGB", (160, 120)).save(root / "images" / f"line1_f{k * 10:06d}.jpg")
        if k < 5:
            (root / "labels" / f"line1_f{k * 10:06d}.txt").write_text(labels[k])
    a = analyse(root, resolution=640)
    assert (a["images"], a["labeled"], a["background"], a["unlabeled"], a["invalid_lines"]) == (6, 5, 1, 1, 2)
    pc = a["per_class"]
    assert [pc[c]["boxes"] for c in ("left_drl", "right_drl", "bolt", "nut")] == [4, 3, 2, 0]
    assert pc["right_drl"]["duplicates"] == 1 and pc["bolt"]["tiny"] == 1 and pc["left_drl"]["presence"] == 0.8
    assert pc["left_drl"]["width_px"] == [32.0, 32.0, 32.0]
    assert a["mirrored_pairs"] and a["sampling"] == {"every": 10, "offset": 0, "naming": "{stem}_f{frame:06d}",
                                                     "image_ext": ".jpg"}
    text = "\n".join(a["warnings"])
    for part in ("1 image(s) have no label file", "2 label line(s) are invalid", "cannot learn them: nut\n",
                 "fewer than 10 boxes: left_drl (4), right_drl (3), bolt (2)\n", "helps): bolt (1)\n",
                 "dropped for training: right_drl (1)"):
        assert part in text


def test_flip_only_without_left_right_pairs_and_batch_plan():
    assert "HorizontalFlip" not in detector.aug_config(["left_drl", "right_drl", "grill"])
    assert detector.aug_config(["bolt", "nut"])["HorizontalFlip"] == {"p": 0.5}
    assert "HorizontalFlip" in detector.aug_config(["left_bolt", "nut"])                  # no pair
    assert "HorizontalFlip" not in detector.aug_config(["license_lamp_left", "license_lamp_right"])   # suffix pair
    from engine.project import lr_pairs
    assert lr_pairs(["rear_left_park", "rear_right_park", "left_drl", "right_drl", "lefty", "side_ind"]) == [
        ("rear_left_park", "rear_right_park"), ("left_drl", "right_drl")]
    assert detector.aug_config(["bolt"], "off") == {}
    assert detector.aug_config(["bolt"], "strong")["HueSaturationValue"]["hue_shift_limit"] == 180
    with pytest.raises(ValueError):
        detector.aug_config(["bolt"], "extreme")
    assert detector.batch_plan("small", 640, 10.5) == (4, 4)                               # as S7 on the 3060
    assert detector.batch_plan("small", 640, None) == (2, 8)                               # CPU
    assert detector.batch_plan("nano", 320, 11.0, n_train=6) == (6, 2)
    with pytest.raises(ValueError):
        detector.check_resolution(600)


def test_threshold_from_f1_sweep():
    targets = [sv.Detections(xyxy=BOXES.copy(), class_id=np.array([0, 1]))] * 3
    pred = sv.Detections(xyxy=np.vstack([BOXES, [[0, 0, 10, 10]]]), class_id=np.array([0, 1, 0]),
                         confidence=np.array([0.8, 0.6, 0.3]))
    sweep = f1_sweep([pred] * 3, targets)
    assert sweep[0.2] == 0.8 and sweep[0.4] == 1.0 and sweep[0.6] == 1.0 and sweep[0.7] == pytest.approx(0.6667, abs=1e-4)
    assert pick_threshold(sweep) == 0.5                               # middle of the 0.35-0.6 plateau
    assert pick_threshold({0.2: 0.5, 0.3: 0.9, 0.4: 0.7}) == 0.3


def test_every_n_from_file_names():
    names = [f"cam_f{i:06d}" for i in (0, 5, 10, 20, 25, 30)]            # f000015 not labeled
    assert infer_sampling(names) == {"every": 5, "offset": 0, "naming": "{stem}_f{frame:06d}"}
    assert infer_sampling(["a_f000003", "a_f000008", "a_f000013"])["offset"] == 3
    assert infer_sampling(["A_f0000", "B_f0000", "A_f0010", "B_f0010"]) == {"every": 10, "offset": 0,
                                                                           "naming": "{stem}_f{frame:04d}"}
    assert infer_sampling(["IMG_001", "IMG_002"]) == {"every": None, "offset": None, "naming": "{name}"}


def test_frames_to_check():
    rows = [("f0", ["a", "b", "c", "c"]), ("f1", ["a", "b", "c", "c"]), ("f2", ["a", "b", "c"]),
            ("f3", ["a"]), ("f4", ["a", "c", "c", "c"])]
    got = frames_to_check(rows, {"a": 0.98, "b": 0.95, "c": 0.3})
    assert got == [{"image": "f3", "boxes": 1, "missing": ["b"]}, {"image": "f4", "boxes": 4, "missing": ["b"]}]
    assert frames_to_check([], {"a": 1.0}) == []


def test_teach_end_to_end_with_a_fake_detector(tmp_path, monkeypatch, fake_detector):
    calls = []

    def fake_train(dataset_dir, out_dir, size, epochs, resolution, aug, resume, progress, should_stop):
        calls.append(resume)
        (out_dir / "checkpoint_best_total.pth").write_bytes(b"x")
        return out_dir / "checkpoint_best_total.pth"

    monkeypatch.setattr(detector, "train", fake_train)
    src, run = make_source(tmp_path / "src"), tmp_path / "run"
    r = teach(src, run, epochs=1, resolution=320)
    assert r["passed"] and r["knowledge_score"] == 100.0 and r["held_out"]["mAP50"] == 1.0
    assert all(v["drop"] == 0 for v in r["held_out"]["stress"].values())
    s = json.loads((run / "settings.json").read_text())
    assert (s["classes"], s["every"], s["naming"], s["checkpoint"]) == (
        ["left_lamp", "right_lamp", "bolt"], 5, "{stem}_f{frame:06d}", "model/checkpoint_best_total.pth")
    assert s["presence"] == {"left_lamp": 1.0, "right_lamp": 1.0, "bolt": 0.0}
    assert "PASS" in (run / "report.md").read_text() and json.loads((run / "report.json").read_text())["passed"]
    stopped = prove(object(), run / "dataset" / "valid", s["classes"], should_stop=lambda: True)   # Stop: no stress test
    assert stopped["mAP50"] == 1.0 and stopped["stress"] == {}
    teach(src, run, epochs=1, resolution=320)                            # complete: no second training
    assert calls == [None]
    (run / "model/trained.json").unlink()                                # interrupted run: resumes
    (run / "model/last.ckpt").write_bytes(b"x")
    teach(src, run, epochs=1, resolution=320)
    assert calls[-1].name == "last.ckpt" and not (run / "model/last.ckpt").exists()


def test_transfer_then_review_with_a_fake_detector(tmp_path, video, fake_detector):
    run = tmp_path / "run"
    run.mkdir()
    (run / "settings.json").write_text(json.dumps({
        "classes": CLASSES, "parent": None, "size": "small", "resolution": 640, "threshold": 0.5, "every": 5,
        "naming": "{stem}_f{frame:06d}", "image_ext": ".jpg", "checkpoint": "model/x.pth",
        "presence": {"left_drl": 1.0, "right_drl": 0.95, "grill": 0.2}}))
    r = transfer(run, [video], tmp_path / "auto")
    out = tmp_path / "auto" / "car_front"
    s = json.loads((out / "summary.json").read_text())
    assert (s["frames"], s["boxes"], s["every"], s["status"]) == (4, 8, 5, "done")
    assert s["boxes_per_class"] == {"left_drl": 4, "right_drl": 4, "grill": 0} and s["frames_to_check"] == []
    assert sorted(p.name for p in (out / "labels").iterdir())[1] == "car_front_f000005.txt"
    assert (out / "preview.mp4").stat().st_size > 0 and (out / "classes.txt").read_text().split() == CLASSES
    assert r["sources"][str(video)]["folder"] == str(out)
    res = runner.invoke(app, ["review", str(tmp_path / "proj"), "--video", str(video), "--labels", str(out / "labels"),
                              "--classes", str(out / "classes.txt")])
    assert res.exit_code == 0, res.output
    assert "4 frames (1 in 5), 8 boxes from 4 label files" in res.output


@pytest.mark.parametrize("cmd", ["app", "new", "export", "teach", "transfer", "export-model", "review", "models", "doctor"])
def test_cli_help(cmd):
    res = runner.invoke(app, [cmd, "--help"])
    assert res.exit_code == 0 and "Usage" in res.output


def test_cli_new_and_export(tmp_path, video):
    classes = tmp_path / "classes.txt"
    classes.write_text("\n".join(CLASSES) + "\n")
    labels = tmp_path / "labels"
    labels.mkdir()
    (labels / "car_front_f000005.txt").write_text("1 0.5 0.5 0.25 0.5\n")
    proj = tmp_path / "proj"
    res = runner.invoke(app, ["new", str(proj), "--video", str(video), "--classes", str(classes), "--labels", str(labels)])
    assert res.exit_code == 0, res.output
    assert "4 frames, 3 classes" in res.output and "imported 1 boxes from 1 label files" in res.output
    res = runner.invoke(app, ["export", str(proj), "--out", str(tmp_path / "out")])
    assert res.exit_code == 0, res.output
    assert (tmp_path / "out/labels/car_front_f000005.txt").read_text().startswith("1 0.5")
    res = runner.invoke(app, ["export", str(proj), "--format", "coco"])
    assert res.exit_code == 0 and len(list((proj / "exports").glob("coco_*/annotations.json"))) == 1
    res = runner.invoke(app, ["new", str(tmp_path / "p2"), "--video", str(video), "--images", str(tmp_path),
                              "--classes", str(classes)])
    assert res.exit_code != 0


def test_training_halves_the_batch_when_the_gpu_runs_out_of_memory(tmp_path, monkeypatch):
    """The T4 (no bf16) needed about 3x the 3060's memory: out of memory at batch 4 -> batch 2, accum 8."""
    from pathlib import Path

    import torch
    ds = tmp_path / "ds"
    for split in ("train", "valid"):
        (ds / split / "images").mkdir(parents=True)
        for k in range(6):
            Image.new("RGB", (32, 32)).save(ds / split / "images" / f"f{k}.jpg")
    (ds / "data.yaml").write_text("names: [bolt, nut]\n")
    calls, released = [], []

    class FakeModel:
        def __init__(self, device):
            pass

        def train(self, batch_size, grad_accum_steps, **kw):
            calls.append((batch_size, grad_accum_steps))
            if batch_size > 2:
                raise RuntimeError("wrapped") from torch.OutOfMemoryError("CUDA out of memory. Tried to allocate 286 MiB")
            Path(kw["output_dir"]).mkdir(parents=True, exist_ok=True)
            (Path(kw["output_dir"]) / "checkpoint_best_total.pth").write_bytes(b"x")

    monkeypatch.setattr(detector, "_model_class", lambda size: FakeModel)
    monkeypatch.setattr(hw, "device", lambda: "cuda")
    monkeypatch.setattr(hw, "free_memory_gb", lambda: 10.5)
    monkeypatch.setattr(hw, "free_gpu_memory", lambda: released.append(1))
    msgs = []
    out = detector.train(ds, tmp_path / "out", "small", epochs=1, progress=lambda d, t, text="": msgs.append(text))
    assert calls == [(4, 4), (2, 8)] and out.name == "checkpoint_best_total.pth" and len(released) == 2
    assert any("Out of GPU memory: starting again with batch 2" in m for m in msgs)

    def always_oom(self, batch_size, grad_accum_steps, **kw):
        calls.append((batch_size, grad_accum_steps))
        raise torch.OutOfMemoryError("CUDA out of memory")
    monkeypatch.setattr(FakeModel, "train", always_oom)
    calls.clear()
    with pytest.raises(torch.OutOfMemoryError):
        detector.train(ds, tmp_path / "out2", "small", epochs=1)
    assert calls == [(4, 4), (2, 8), (1, 16)]                         # down to batch 1, then gives up


def test_onnx_decode_scores_each_class_and_drops_background():
    dets = np.array([[0.5, 0.5, 0.2, 0.4], [0.1, 0.1, 0.1, 0.1]], np.float32)
    labels = np.array([[4.0, 3.0, 9.0], [-9.0, -9.0, 9.0]], np.float32)     # last column: background
    xyxy, scores, cls, q = detector.onnx_decode(dets, labels, 100, 50, 0.5)
    assert list(q) == [0, 0]
    plane = np.where(np.arange(8) < 4, 5.0, -5.0)[None, :].repeat(4, 0)            # left half inside
    px = detector.onnx_masks(np.stack([plane, -plane]), q, 16, 8)
    assert px.shape == (2, 8, 16) and px[0, :, :7].all() and not px[0, :, 9:].any()
    assert list(cls) == [0, 1] and scores[0] > scores[1]                     # one query, two classes: both kept
    assert np.allclose(xyxy, [[40, 15, 60, 35]] * 2)
    x = detector.onnx_input(Image.new("RGB", (64, 32), (255, 0, 0)), 32)
    assert x.shape == (1, 3, 32, 32) and abs(x[0, 0, 5, 5] - (1 - 0.485) / 0.229) < 1e-4


def test_the_production_bundle_prepares_and_decodes_like_the_export(tmp_path):
    from engine import build_engine as B
    rgb = np.random.default_rng(0).integers(0, 256, (48, 80, 3), dtype=np.uint8)
    card = {"resolution": 32, "input": {"mean": list(detector.MEAN), "std": list(detector.STD)}}
    assert np.abs(B.prepare(rgb, card) - detector.onnx_input(Image.fromarray(rgb), 32)).max() < 1e-4
    dets = np.random.default_rng(1).random((6, 4), np.float32)
    labels = np.random.default_rng(2).normal(0, 3, (6, 4)).astype(np.float32)
    for a, b in zip(B.decode(dets, labels, 80, 48, 0.3), detector.onnx_decode(dets, labels, 80, 48, 0.3)):
        assert np.allclose(a, b)
    out = tmp_path / "out.json"                               # trtexec --exportOutput layout
    out.write_text('[ { "name" : "dets"\n, "dimensions" : "1x2x2"\n, "values" : [ 1, 2, 3, 4 ]\n}\n]')
    assert B.read_outputs(out)["dets"].tolist() == [[[1, 2], [3, 4]]]
    assert [B.trt_major(f"&&&& RUNNING TensorRT.trtexec [TensorRT v{v}]") for v in (110300, 101500, 8601)] == [11, 10, 8]


def test_outlines_become_one_polygon_per_part():
    import cv2
    from engine.teach import line_box, mask_polygon, polygon_line
    m = np.zeros((40, 80), bool)
    m[10:20, 5:25] = m[12:18, 50:70] = True                  # one part in two pieces
    poly = mask_polygon(m)
    back = np.zeros((40, 80), np.uint8)
    cv2.fillPoly(back, [np.round(poly - 0.5).astype(np.int32)], 1)
    assert (back.astype(bool) & m).sum() / (back.astype(bool) | m).sum() > 0.9
    c, x1, y1, x2, y2 = line_box(polygon_line(2, poly, 80, 40))
    assert c == 2 and x1 < 5 / 80 + 0.01 and x2 > 69 / 80 and y1 < 10 / 40 + 0.02 and y2 > 17 / 40
    assert line_box("1 0.5 0.5 0.2 0.4") == (1, 0.4, 0.3, 0.6, 0.7) or np.allclose(line_box("1 0.5 0.5 0.2 0.4")[1:], (0.4, 0.3, 0.6, 0.7))
    assert mask_polygon(np.zeros((5, 5), bool)) is None


def test_outline_models_train_on_polygons_in_stages(tmp_path, monkeypatch, fake_detector):
    from engine.teach import load_targets, mask_ious
    src = make_source(tmp_path / "src")
    (src / "polygons").mkdir()
    for f in (src / "labels").iterdir():                     # the two lamps outlined as diamonds
        (src / "polygons" / f.name).write_text("0 0.25 0.4 0.35 0.5 0.25 0.6 0.15 0.5\n1 0.75 0.4 0.85 0.5 0.75 0.6 0.65 0.5\n")
    trained = []

    def fake_train(dataset_dir, out_dir, size, epochs, resolution, aug, resume, progress, should_stop):
        trained.append((size, resolution))
        (out_dir / "checkpoint_best_total.pth").write_bytes(b"x")
        return out_dir / "checkpoint_best_total.pth"
    monkeypatch.setattr(detector, "train", fake_train)
    run = tmp_path / "run"
    with pytest.raises(ValueError, match="multiple of 24"):
        teach(src, run, size="seg-small", resolution=320)
    r = teach(src, run, size="seg-small", resolution=384, epochs=1, stage="prepare")
    assert r["status"] == "prepared" and not trained
    label = next((run / "dataset" / "valid" / "labels").iterdir())
    assert len(label.read_text().splitlines()[0].split()) == 9          # class + 4 points
    t = load_targets(label, 160, 120)
    assert np.allclose(t.xyxy[0], [24, 48, 56, 72]) and t.data["polygons"][0].shape == (4, 2)
    moved = tmp_path / "elsewhere"                                        # e.g. a cloud GPU
    shutil.copytree(run, moved)
    r = teach(None, moved, size="seg-small", resolution=384, epochs=1, stage="train")
    assert r["status"] == "done" and trained == [("seg-small", 384)] and r["held_out"]["mAP50"] == 1.0
    pred = sv.Detections(xyxy=t.xyxy[:1], class_id=np.array([0]), confidence=np.array([0.9]),
                         mask=np.zeros((1, 120, 160), bool))
    pred.mask[0, 48:72, 24:56] = True                                     # the box as outline: diamond is half of it
    (c, iou), = mask_ious(pred, t)
    assert c == 0 and 0.4 < iou < 0.65
    for f in list((src / "labels").iterdir())[::2]:                     # half the frames empty
        f.write_text("")
        (src / "polygons" / f.name).write_text("")
    thin = teach(src, tmp_path / "thin", size="seg-small", resolution=384, stage="prepare", empty_every=3)
    kept = [f for f in (tmp_path / "thin" / "dataset" / "train" / "labels").iterdir()]
    held = [f for f in (tmp_path / "thin" / "dataset" / "valid" / "labels").iterdir()]
    left, kept_empty, held_empty = (thin["boxes"]["empty_left_out"], sum(not f.read_text() for f in kept),
                                    sum(not f.read_text() for f in held))
    assert left > 0 and kept_empty + left + held_empty == 10 and held_empty > 0   # held-out empties all kept
    with pytest.raises(ValueError, match="outlines"):
        teach(make_source(tmp_path / "boxes_only"), tmp_path / "run2", size="seg-small", resolution=384, stage="prepare")
